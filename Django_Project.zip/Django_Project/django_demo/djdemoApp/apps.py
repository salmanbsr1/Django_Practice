from django.apps import AppConfig


class DjdemoappConfig(AppConfig):
    name = 'djdemoApp'

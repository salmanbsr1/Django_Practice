from django.shortcuts import render

# Create your views here.
from django.http import HttpResponse


def index(request):
    return HttpResponse("Hello, world. You're at the polls index.")


def assign1(request):
    img = "<img src='polls/images/logo.png' alt='Python logo'>"
    page = "<h1>Welcome to my Website!</h1> <p>I'm excited to eventually learn Django!</p><br>" \
           "<a href='https://www.djangoproject.com/'>Here is a link to the official Django Website</a><br>" \
           "<p>Here is a picture of the Python Logo:</p>" + img + "<p>Here are three reasons Django is cool</p>" \
                                                                  "<ol>" \
                                                                  "<li>Ridiculously Fast</li>" \
                                                                  "<li>Reassuringly Secure</li>" \
                                                                  "<li>Exceedingly Scalable</li></ol>" \
                                                                  "<h1>Bonus: Optional Extra Credit</h1>" \
                                                                  "<p>Can you figure out how to make a picture a link?</p>" \
                                                                  "<a href ='https://www.djangoproject.com/'><img src='a.png' alt =' '></a>"
    return HttpResponse(page)


def assign1(request):
    return render(request, "test.html")


def assign2(request):
    return render(request, "assign2.html")


'''
# Django Templates
# Template tags django
# template filter with django
# Loading templte in django


'''
